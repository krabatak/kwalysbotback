var init = function () {
    var btns = document.getElementsByClassName("btn");
    for (var i = 0; i < btns.length; i++) {

        btns[i].addEventListener("click", function () {
            var nodeElement = getNodeByClickedBtn(this);
            var action = this.getAttribute("data-action");
            var id = nodeElement.getAttribute("data-node-id");
            var node = orgChart.nodes[id];

            switch (action) {
                case "add":
                    orgChart.insertNode(id);
                    break;
                case "edit":
                    document.getElementById("hdnId").value = node.id;
                    document.getElementById("txtName").value = node.data.name ? node.data.name : "";
                    document.getElementById("txtTitle").value = node.data.title ? node.data.title : "";
                    document.getElementById("txtMail").value = node.data.mail ? node.data.mail : "";
                    $("#dialog").dialog("open");
                    break;
                case "delete":
                    orgChart.removeNode(id);
                    break;
            }
        });
    }
};
function draggable() {
//    $('div.ps-popup-outer').draggable();
}
Ctrl
        .controller("BotsCtrl", function ($scope, $rootScope, $timeout, $document, $window, $routeParams, $location, $cookies, $cookieStore, BotsFactory) {
            init_dashboard();
            var currentHash = document.location.hash;
            //List Bots function
            if (currentHash === "#/bots/index") {
                $rootScope.pageTitle = "Liste des bots";
                BotsFactory.getAllBots()
                        .then(function (response) {
                            $scope.records = response.data
                        }, function (data) {
                            toastr.error("Le serveur d'api ne répond pas");
                        })
                        .catch(function (fallback) {
                            console.log(fallback);
                        });
            }
            if (currentHash.search("#/bots/tree-") > -1) {
                new Clipboard('#copy-button');
                $rootScope.pageTitle = "Arbre des Q/R";
                var idBot = $routeParams.id;
                BotsFactory.getTreeBotByID(idBot)
                        .then(function (response) {
//                            console.log(response.data);
                            $scope.botId = idBot;
                            $scope.botname = response.botname;
                            $scope.tree = response.data;
                            var data = [
                                {id: 1, parentId: null, name: "Amber McKenzie", title: "CEO"},
                                {id: 2, parentId: 1, name: "Ava Field", title: "Paper goods machine setter"},
                                {id: 3, parentId: 1, name: "Evie Johnson", title: "Employer relations representative", mail: "thornton@armyspy.com"}
                            ];
                            var organigramme = [];

                            angular.forEach($scope.tree, function (obj, index) {
                                var parentID = null;
                                if (obj.Reponse.parentId !== null && obj.Reponse.parentId !== undefined && obj.Reponse.parentId !== "null") {
                                    parentID = obj.Reponse.parentId["$id"] || obj.Reponse.parentId;
                                }
                                organigramme.push({
                                    id: obj.Reponse.id,
                                    parentId: parentID,
                                    Question: obj.Reponse.in_response_to,
                                    Réponse: obj.Reponse.text,
                                    Suggestions: "Ma Sug",
                                    Keywords: obj.Reponse.extra_data,
//                                    pic: base_url() + "images/chat_red.png"
                                });
                            });
//                            console.log(organigramme);
                            var orgChart = new getOrgChart(document.getElementById("people"), {
                                primaryFields: ["Question", "Réponse", "Suggestions", "Keywords"],
//                                photoFields: ["pic"],
                                theme: "vivian",
                                enableEdit: true,
                                linkType: "B",
                                enableDetailsView: true,
                                insertNodeEvent: function (sender, args) {
                                    console.log(args.node);
                                    var idNode = null;
                                    if (isNaN(args.node.id)) {
                                        idNode = args.node.id;
                                    }
                                    var dataTree = {
                                        id: idNode,
                                        text: args.node.data.Réponse,
                                        in_response_to: args.node.data.Question,
                                        extra_data: args.node.data.Keywords,
                                        bot_id: $routeParams.id,
                                        parentId: args.node.pid || null
                                    };
                                    console.log(dataTree);
                                    BotsFactory.updateEvent(dataTree)
                                            .then(function (response) {
//                                                console.log(response);
                                                toastr.info(response.text);
                                                var idBot = response.lastID;
                                                args.node.id = idBot;
                                                console.log(args.node);
                                            },
                                                    function (error) {
                                                        toastr.error("Le serveur d'api ne répond pas");
                                                    });
                                },
                                removeNodeEvent: function (sender, args) {
                                    var nodeID = args.id;
                                    var r = confirm("êtes vous sûr ?");
                                    if (r == true) {
                                        BotsFactory.deleteNode(nodeID)
                                                .then(function (response) {
                                                    toastr.info(response.text);
                                                }, function (error) {
                                                    toastr.error("Le serveur d'api ne répond pas");
                                                });
                                    } else {
                                        return false;
                                    }

                                },
                                updateNodeEvent: function (sender, args) {
//                                    console.log(sender);
                                    console.log(args.node);
                                    var idNode = null;
                                    if (isNaN(args.node.id)) {
                                        idNode = args.node.id;
                                    }
                                    var dataTree = {
                                        id: idNode,
                                        text: args.node.data.Réponse,
                                        in_response_to: args.node.data.Question,
                                        extra_data: args.node.data.Keywords,
                                        bot_id: $routeParams.id,
                                        parentId: args.node.pid || null
                                    };
                                    console.log(dataTree);
                                    BotsFactory.updateEvent(dataTree)
                                            .then(function (response) {
//                                                console.log(response);
                                                toastr.info(response.text);
                                                var idBot = $routeParams.id;
                                                var length = orgChart.config.dataSource;
                                                console.log(orgChart.config.dataSource[length - 1]);
//                                                orgChart.da
                                            },
                                                    function (error) {
                                                        toastr.error("Le serveur d'api ne répond pas");
                                                    });
                                },
                                updatedEvent: function (sender, args) {
//                                    console.log(sender);
//                                    console.log(args);
//                                    var modelTree = [];
//                                    for (var id in orgChart.nodes) {
//                                        var node = orgChart.nodes[id];
////                                        console.log(node);
////                                        console.log(node.pid);
////                                        console.log(node['id']);
////                                        console.log(node['data']);
//                                        var idNode = null;
//                                        if (isNaN(node['id'])) {
//                                            idNode = node['id'];
//                                        }
//                                        var dataTree = {
//                                            id: idNode,
//                                            text: node['data'].Réponse,
//                                            in_response_to: node['data'].Question,
//                                            extra_data: node['data'].Keywords,
//                                            bot_id: $routeParams.id,
//                                            parentId: node.pid || null
//                                        };
//                                        modelTree.push(dataTree);
//                                    }
////                                    console.log(modelTree);
//                                    BotsFactory.updateEvent(modelTree)
//                                            .then(function (response) {
////                                                console.log(response);
////                                                toastr.info(response.text);
//                                                var idBot = $routeParams.id;
////                                                orgChart.da
//                                            },
//                                                    function (error) {
//                                                        toastr.error("Le serveur d'api ne répond pas");
//                                                    });
                                },
                                dataSource: organigramme
                            });
                            $timeout(draggable, 1000);
                        },
                                function (response) {
                                    console.log(data);
                                    toastr.error("Le serveur d'api ne répond pas");
                                });
            }
            if (currentHash.search("#/bots/add") > -1) {
                $rootScope.pageTitle = "Ajout Bot";
            }
            if (currentHash.search("#/bots/edit-") > -1) {
                $rootScope.pageTitle = "Modif Bot";
                var idBot = $routeParams.id;
                BotsFactory.getBotByID(idBot)
                        .then(function (response) {
                            $timeout(function () {
                                console.log(response.data);
                                $scope.bot = response.data;
                            }, 599);
                        }, function (data) {
                            console.log(data);
                            toastr.error("Le serveur d'api ne répond pas");
                        })
                        .catch(function (fallback) {
                            console.log(fallback);
                        });
            }
            //edit bot
            $scope.editBot = function ($event) {
                $event.preventDefault();
                if ($scope.bot.Bot.name == undefined) {
                    toastr.info("Veuillez choisir un nom pour votre bot");
                } else {
                    var dataBot = {
                        Bot: {
                            id: $scope.bot.Bot.id,
                            name: $scope.bot.Bot.name,
                            content: $scope.bot.Bot.content
                        }
                    };
//                    console.log(dataBot);
                    BotsFactory.saveBot(dataBot)
                            .then(function (response) {
                                toastr.info(response.text);
                                $location.path("/bots/index");
                            }, function (data) {
                                toastr.error("Le serveur d'api ne répond pas");
                            })
                            .catch(function (fallback) {
                                console.log(fallback);
                            });
                }
                ;
            };
            //path add bot
            $scope.callAdd = function () {
                var botNumber = $scope.records.length;
                if (botNumber < 5) {
                    $location.path("/bots/add");
                } else {
                    toastr.info("Vous avez atteint le nombre maximal de bot.");
                }
            };
            //call referrer
            $scope.cancel = function () {
                history.go(-1);
            };
            //add bot function
            $scope.addBot = function ($event) {
                $event.preventDefault();
                if ($scope.botName == undefined) {
                    toastr.info("Veuillez choisir un nom pour votre bot");
                } else {
                    var dataBot = {
                        Bot: {
                            name: $scope.botName,
                            content: $scope.botInfo || ""
                        }
                    };
//                    console.log(dataBot);
                    BotsFactory.saveBot(dataBot)
                            .then(function (response) {
                                toastr.info(response.text);
                                $location.path("/bots/index");
                            }, function (data) {
                                console.log(data);
                                toastr.error("Le serveur d'api ne répond pas");
                            })
                            .catch(function (fallback) {
                                console.log(fallback);
                            });
                }
            };
        });